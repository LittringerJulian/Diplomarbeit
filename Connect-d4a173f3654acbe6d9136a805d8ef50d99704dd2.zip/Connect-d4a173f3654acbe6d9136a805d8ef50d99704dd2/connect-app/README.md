# ConnectApp

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 8.3.20.

## Development server

`npm run start:electron` zum starten!

